<?php
include 'connect.php';

$Id = $_POST['Id']; 
$psw = $_POST['psw']; 
$repeatPsw = $_POST['psw-repeat']; 

$getId="select * from voter where ElectionId='$Id'";
$runId = mysqli_query($connection,$getId);
$rows = mysqli_fetch_assoc($runId);
$EId=$rows['ElectionId'];
$reg=$rows['registered'];
if($EId==$Id)
{
	if($reg=='No'){
		$query = "update voter set registered='Yes', password='$psw' where ElectionId='$Id'"; 
		$data = mysqli_query($connection,$query)or die(mysql_error()); 
		if($data) 
		{ echo "<script>
			alert('YOUR REGISTRATION IS COMPLETED! Please Login');
			window.location.href='userLogin.php';
			</script>"; 
			
		}
	}
	else{
		echo "<script>
			alert('You are already registered');
			window.location.href='userLogin.php';
			</script>"; 
	}
	
}
else
	echo "<script>
		alert('Not a valid Election Id');
		window.location.href='userLogin.php';
		</script>";
?>