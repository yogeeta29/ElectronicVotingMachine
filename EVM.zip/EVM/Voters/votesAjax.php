<style>
.btn{
	background-color:blue;
	color:white;
}
</style>
<?php
include 'session.php';

	//$subject = mysqli_real_escape_string($connection, strip_tags($_REQUEST['sid']));
	//$att_date = mysqli_real_escape_string($connection, strip_tags($_REQUEST['attd_date']));
		
		$sql="select * from candidate ";
		$run = mysqli_query($connection,$sql);

		while ($rows = mysqli_fetch_assoc($run)) {
			echo "
				<tr>
					<td>$rows[c_id]</td>
					<td>";?><img src="../Admin/<?php echo $rows["symbol"] ?>" height="80" width="80"><?php echo"</td>
					<td>$rows[name]</td>
					<td>
						<button class='btn' onclick=CastVote('$rows[c_id]')>Vote</button> 
					</td>
				</tr>
			";
		}
	



/*if(isset($_REQUEST['absent_id'])){
	$subject = mysqli_real_escape_string($connection, strip_tags($_REQUEST['sub_id']));
	$att_date = mysqli_real_escape_string($connection, strip_tags($_REQUEST['attd_date']));
	
	//echo $subject;
	$login=$login_session;
	$fact="select fact_id,dept_name from facultylogin where username='$login'";
	$s=mysqli_query($connection,$fact);
	$row3 = mysqli_fetch_assoc($s);
	$fact_id=$row3['fact_id'];
	$dept_name=$row3['dept_name'];

	$query="select course_id from courses where fact_id='$fact_id' and dept_name='$dept_name'";
	$res = mysqli_query($connection,$query);
	$row = mysqli_fetch_assoc($res);
	$course_id=$row['course_id'];
	
	$query1="insert into attendance(attd_date,Last_Date,stud_id,dept_name,course_id,sub_id,fact_id) values('$att_date','$att_date','$_REQUEST[absent_id]','$dept_name','$course_id','$subject','$fact_id')";
	mysqli_query($connection,$query1);
	
		$query="select a.Absent_Count,a.Present_Count,a.Total_Classes from attendance a where stud_id='$_REQUEST[absent_id]' and course_id='$course_id' and sub_id='$subject'";
		$res = mysqli_query($connection,$query);
		$row2=mysqli_fetch_assoc($res);
		$a = $row2['Absent_Count'];
		$b = $row2['Present_Count'];
		$c = $row2['Total_Classes'];

		$absent_sql = "update attendance set Absent_Count= $a + 1,Total_Classes= $c + 1,Last_Date='$att_date' where stud_id='$_REQUEST[absent_id]' and course_id='$course_id' and sub_id='$subject'";
		mysqli_query($connection,$absent_sql);
		
	$sql="select e.stud_id,s.stud_name from enroll e,student s where e.course_id='$course_id' and e.sub_id='$subject' and s.course_id = '$course_id' and s.stud_id=e.stud_id";
	$run = mysqli_query($connection,$sql);

	while ($rows = mysqli_fetch_assoc($run)) {
		echo "
			<tr>
				<td>$rows[stud_id]</td>
				<td>$rows[stud_name]</td>
				<td>
					<button class='btn btn-success' onclick=present_stud('$rows[stud_id]','$subject','$att_date')>Present</button> 
					<button class='btn btn-danger' onclick=absent_stud('$rows[stud_id]','$subject','$att_date')>Absent</button>
				</td>
			</tr>
		";
	}
}*/	
	
if(isset($_REQUEST['ID'])){
	//$Name = mysqli_real_escape_string($connection, strip_tags($_REQUEST['Name']));
	
	$d=strtotime("today");
	$d= date("Y-m-d", $d);
	
	$sql_name = "select * from startelection";
	$result_name = mysqli_query($connection,$sql_name);
	$row_name=mysqli_fetch_assoc($result_name);
	$elec_name = $row_name['ElecName'];
	
	$sql_can = "select * from candidate where c_id='$_REQUEST[ID]'";
	$result_can = mysqli_query($connection,$sql_can);
	$row_can=mysqli_fetch_assoc($result_can);
	$name = $row_can['name'];
	$symbol= $row_can['symbol'];

	$query1="insert into votes(Date,elec_name,ID,Candidate,symbol) values('$d','$elec_name','$_REQUEST[ID]','$name','$symbol')";
	mysqli_query($connection,$query1);
	
		$query="select Vote from votes where ID='$_REQUEST[ID]' and Date='$d'";
		$res = mysqli_query($connection,$query);
		$row2=mysqli_fetch_assoc($res);
		$a = $row2['Vote'];

		$absent_sql = "update votes set Vote= $a + 1 where ID='$_REQUEST[ID]' and Date='$d'";
		mysqli_query($connection,$absent_sql);
		
		$login=$login_session;
			$user="select * from voter where username='$login'";
			$userDetails=mysqli_query($connection,$user);
			$row = mysqli_fetch_assoc($userDetails);
			$ElectionId=$row['ElectionId'];
			
		$update_voted = "update voter set voted='1' where ElectionId='$ElectionId'";
		mysqli_query($connection,$update_voted);
	
	
	
		
	
}	
?>