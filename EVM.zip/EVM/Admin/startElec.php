<!DOCTYPE HTML>
<?php
include 'session.php';
?>
<html>
<head>
	
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

	<title>Start Election</title>
	
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/business-casual.min.css" rel="stylesheet">
	 	
</head>
<body style="background-color:rgba(47, 23, 16, 1);">
	<h1 class="site-heading text-center text-white d-none d-lg-block">
      <span class="site-heading-upper text-primary mb-3">EVM ONLINE</span>
      <span class="site-heading-lower">Vote From Home</span>
    </h1>
	 	<?php include("include/LoginName.php"); ?>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="AdminProfile.php">EVM ONLINE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="AdminProfile.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="about.php">About</a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="products.php">Parties</a>
            </li>
			
			<li class="nav-item active px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="startElec.php">Start Election</a>
            </li>
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="result.php">Result</a>
            </li>
			
			<div class="dropdown nav-item px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Voters</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_voters.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="viewVoters.php">View/Edit</a>
			  </li>
			</div>
			<div class="dropdown nav-item px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Candidates</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_candidates.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="view_candidates.php">View/Edit</a>
			  </li>
			</div>

			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="../logout.php">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	
	<?php
		$ElectDetails="select * from startelection";
		$ElecResults= mysqli_query($connection,$ElectDetails);
		$num = mysqli_num_rows($ElecResults);
		
		
		$timezone = new DateTimeZone("Asia/Kolkata" );
		$date = new DateTime();
		$date->setTimezone($timezone );
		$cur_date = $date->format( 'Y-m-d' );

		/*while($row_date = mysqli_fetch_assoc($ElecResults)){
		$start=$row_date['start_date'];
		}*/
		
		if ($num > 0){
		 ?>
		 <script>
			function EndElec(){
				xmlhttp = new XMLHttpRequest();
				var ans = confirm ("Are you sure? *Candicate details will be deleted* ");
				if (ans){
					xmlhttp.open('GET','endElec.php',true);
					xmlhttp.send();
					window.location.href='startElec.php';
				}
			}
			
			
		 </script>
			
			<section class="page-section cta">
			  <div class="container">
				<div class="row">
				  <div class="col-xl-9 mx-auto">
					<?php
						echo "<h2>Election Has already started</h2>";
					?>
					<button onclick="EndElec()" type="submit" id="end" class="btn btn-success" name="end" value="end">End Election</button>
					<a href="ElecDetails.php"><button type="submit" id="det" class="btn btn-success" name="det" value="det">Election Details</button></a>
				  </div>
				</div>
			  </div>
			</section>		 
		 <?php
		} else {
		
	?>
	<div class="h_btm_bg" style="color:white;">	
		<div class="about-section" id="contact" style="">
		<section class="page-section clearfix">
			<div class="container">
				<div class="contact-header">
					<center><span style=""><h3>Start Election</h3></span></center><br><br>
				</div>				
				<center>		
				<form id="defaultForm" name="form" method="post" class="form-horizontal" action="StartElection_action.php" enctype="multipart/form-data">
               
					<div class="form-group">
                        <label class="col-lg-3 control-label" for="name">Election Name</label>
                        <div class="col-lg-4">
                            <input name="name" type="text" class="form-control input-md" style="width:300px" required>
                        </div>
                    </div>
					
                    <div class="form-group">
                        <label class="col-lg-3 control-label" for="">Start Date</label>
                        <div class="col-lg-5">
                            <input type="date" name="SD" id="datepickertest" class="datepicker form-control input-md" style="width:300px"/>
                        </div>
                    </div>
                   
					<div class="form-group">
						<label class="col-lg-3 control-label" for="phone">Start Time</label>
						<div class="col-lg-4">
							<input type="time" id="ST" name="ST" class="form-control input-md" style="width:300px" maxlength="10" required>
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-lg-3 control-label" for="phone">End Time</label>
						<div class="col-lg-4">
							<input type="time" id="ET" name="ET" class="form-control input-md" style="width:300px" maxlength="10" required>
						</div>
					</div>
					
					<div class="form-group">
							<div class="col-lg-9 col-lg-offset-3">
								<button type="submit" id="start" class="btn btn-success" name="start" value="Start">Start</button>
								<button type="reset" class="btn btn-info" name="" value="reset">Reset</button>
							</div>
					</div>
                </form>
				</center>
            </div>
		</section>
        </div>
    </div>
		<?php }?>
	<?php include("include/footer.php"); ?>
    
	<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	
</body>