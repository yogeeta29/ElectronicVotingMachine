<?php
include 'session.php';

		
	$sql3 = "delete from startelection";
	mysqli_query($connection,$sql3);
	
	$sql4 = "delete from candidate";
	mysqli_query($connection,$sql4);
	
	
		

?>