<!DOCTYPE HTML>
<html>
<head> <!-- Done -->
	
		<?php 
			include 'session.php';
			include("include/html_include.php");
			//scripts();
			//validate();
			
			$ElectionId = $_GET['id'];
			$sql="SELECT * FROM  voter where ElectionId=$ElectionId ";
			$result = mysqli_query($connection,$sql);
			while ($row = mysqli_fetch_array($result))
			{
				$election_id=$row["ElectionId"];
				$name=$row["Name"];
				$address=$row["address"];
				$mobile=$row["mobile"];
				$email_id=$row["email_id"];
				$ward_no=$row["ward_no"];
			}
		?>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

	<title>Update Voters</title>
	
	<!-- $title is to display title on nav bar -->
	<?php
		$title='Voters Registration';
	?>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/business-casual.min.css" rel="stylesheet">
    <script>
		function validateEmail() {
			var x = document.forms["form"]["email_id"].value;
			var atpos = x.indexOf("@");
			var dotpos = x.lastIndexOf(".");
			if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
				alert("Not a valid e-mail address");
				return false;
			}
		}
	</script>
	 
	 
	
</head>
<body style="background-color:rgba(47, 23, 16, 1);">
	<h1 class="site-heading text-center text-white d-none d-lg-block">
      <span class="site-heading-upper text-primary mb-3">EVM ONLINE</span>
      <span class="site-heading-lower">Vote From Home</span>
    </h1>
	 	<?php include("include/LoginName.php"); ?>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
      <div class="container">
        <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="AdminProfile.php">EVM ONLINE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="AdminProfile.php">Home
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="about.php">About</a>
            </li>
            <li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="products.php">Parties</a>
            </li>
			
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="startElec.php">Start Election</a>
            </li>
			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="result.php">Result</a>
            </li>
			
			<div class="dropdown nav-item active px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Voters</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_voters.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="viewVoters.php">View/Edit</a>
			  </li>
			</div>
			<div class="dropdown nav-item px-lg-4">
			  <button class="dropbtn nav-link text-uppercase text-expanded">Candidates</button>
			  <li class="dropdown-content">
				<a class="nav-link text-uppercase text-expanded" href="Register_candidates.php">Register</a>
				<a class="nav-link text-uppercase text-expanded" href="view_candidates.php">View/Edit</a>
			  </li>
			</div>

			<li class="nav-item px-lg-4">
              <a class="nav-link text-uppercase text-expanded" href="../logout.php">logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	
	<?php //register_header(); ?>
	<div class="h_btm_bg" style="color:white;">	
		<div class="about-section" id="contact" style="">
		<section class="page-section clearfix">
			<div class="container">
				<div class="contact-header">
					<center><span style=""><h3>Update Voters Details</h3></span></center><br><br>
				</div>				
				<center>		
				<form id="defaultForm" name="form" method="post" class="form-horizontal" action="update_voter_action.php?id=<?php echo $ElectionId ?>&address=<?php echo $address ?>" enctype="multipart/form-data"  onsubmit="return validateEmail();">
               
					<div class="form-group">
                        <label class="col-lg-3 control-label" for="id">Election_Id</label>
                        <div class="col-lg-4">
                            <input name="ElectionId" type="text" class="form-control input-md" style="width:300px" required value="<?php echo $election_id;?>" disabled/>
                        </div>
                    </div>
					
					 <div class="form-group">
                        <label class="col-lg-3 control-label" for="name">Name</label>
                        <div class="col-lg-4">
                            <input name="Name" type="text" class="form-control input-md" style="width:300px" required value="<?php echo $name;?>" />
                        </div>
                    </div>

                     <div class="form-group">
                        <label class="col-lg-3 control-label" for="address">Address</label>
                        <div class="col-lg-4">
							<textarea class="form-control"  name="address" style="width:300px"><?php echo $address;?></textarea>
						</div>
                    </div>
					
                   
					<div class="form-group">
						<label class="col-lg-3 control-label" for="mobile">mobile</label>
						<div class="col-lg-4">
							<input id="mobile" name="mobile" type="text" pattern="\d*" class="form-control input-md" style="width:300px" maxlength="10" required value="<?php echo $mobile;?>"  />
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-lg-3 control-label" for="email_id">email_id</label>
						<div class="col-lg-4">
                            <input name="email_id" type="text" class="form-control input-md" style="width:300px" required value="<?php echo $email_id;?>" />
                        </div>
						
					</div>
					
					<div class="form-group">
						<label class="col-lg-3 control-label" for="ward_no">ward_no</label>
						<div class="col-lg-4">
							<input id="ward_no" name="ward_no" type="number" class="form-control input-md" style="width:300px"  required value="<?php echo $ward_no;?>"  />
						</div>
                    </div>
					<div class="form-group">
							<div class="col-lg-9 col-lg-offset-3">
								<button type="submit" id="register" class="btn btn-success" name="register" value="register">Update</button>
								<button type="reset" class="btn btn-info" name="" value="reset">Reset</button>
							</div>
					</div>
                </form>
				</center>
            </div>
		</section>
        </div>
    </div>
	
	<?php include("include/footer.php"); ?>
    
	<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	
</body>