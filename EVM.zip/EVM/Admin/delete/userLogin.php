<?php
include('login.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
header("location: UserProfile.php");
}
?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Assests/images/favicon.ico">
	  <link href="Assests/AddCourses.css" rel="stylesheet">


    <title>Login</title>


    <!-- Custom styles for this template -->
    <link href="Assests/css/signin.css" rel="stylesheet">
	<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function validate(){
	var x=document.getElementById('psw').value;
	var y=document.getElementById('psw-repeat').value;
	if(x!=y){
		alert("Password didn't match. Try Again!!");
	}
}
</script>
</head>

<body style="font-family: Trebuchet MS;">
<div align="center">

<div class="container" align="center">
		<header align="center">
            <h2  align="center">FACULTY lOGIN</h2>
		</header>
        <form class="form-signin" method="post" align="center"><br>

            <input type="text" style="width:100%;" id="inputUsername" class="form-control" placeholder="Username" name="username" required autofocus><br><br>
            <input type="password" style="width:100%;" id="inputPassword" class="form-control" placeholder="Password" name="password" required><br><br>

			<button id="myBtn" style="width:100%;" class="btn btn-lg btn-primary btn-block" name="submit" type="submit">Login</button><br><br>
			<a href="forgot.php" style="color:black;">Forgot Password</a>

		</form>
</div>
</div>
</body>

</html>