<?php
	
	include "session.php";
	$c_id = $_GET['id'];
	$symbol= $_GET['symbol'];
	$loc= $_GET['location'];
	function GetImageExtension($imagetype)
   	{
       if(empty($imagetype)) return false;
       switch($imagetype)
       {
           case 'image/bmp': return '.bmp';
           case 'image/gif': return '.gif';
           case 'image/jpeg': return '.jpg';
           case 'image/png': return '.png';
           default: return false;
       }
    }
		
	if(isset($_POST["register"]))  
	{
			$name =	$_POST['name']; 
			$party =$_POST['party']; 
			$doe =	$_POST['DOE']; 
			$location =	$_POST['location']; 
			$phno =	$_POST['phno']; 
			
		if($location=='')
		{
			$location=$loc;
		}
			
		if (!empty($_FILES["img_file"]["name"])) 
		{

			$file_name=$_FILES["img_file"]["name"];
			$temp_name=$_FILES["img_file"]["tmp_name"];
			$imgtype=$_FILES["img_file"]["type"];
			$ext= GetImageExtension($imgtype);
			$imagename=date("d-m-Y")."-".time().$ext;
			//$imagename=$party.$ext;
			$target_path = "images/".$imagename;
			

			if(move_uploaded_file($temp_name, $target_path)) 
			{
				
				/*$sql = " INSERT INTO `candidate`(`name`, `party`, `doe`, `location`, `phno`,`symbol`) VALUES 
										('$name','$party','$doe','$location','$phno','".$target_path."')";
				*/
				$sql = "UPDATE `candidate` SET `name`='$name',`party`='$party',`DOE`='$doe',`location`='$location',`phno`='$phno',`symbol`='".$target_path."' WHERE `c_id`='$c_id' ";

				mysqli_query($connection,$sql);

				// ----------------------------------------------------------------------
				
			}
			else
			{

			   exit("Error While uploading image on the server");
			} 

		}
		else
		{
			$sql = "UPDATE `candidate` SET `name`='$name',`party`='$party',`DOE`='$doe',`location`='$location',`phno`='$phno',`symbol`='$symbol' WHERE `c_id`='$c_id' ";

			mysqli_query($connection,$sql);
		}


	}
?>
<!DOCTYPE html>
<html>
<head>
<title>Candidate Update</title>   

		<?php include("include/html_include.php"); 
			   include("include/connect.php"); 
		?>

<?php  scripts(); ?>
 <link href="css/business-casual.min.css" rel="stylesheet">	
</head>

<body style="background-color:rgb(45, 29, 26);">
<?php //register_header(); ?>
	<div class="h_btm_bg" style="color:white;">	
		<?php //admin_sidebar(); ?>
		<div class="about-section" id="contact" style="">
			<div class="container">
				<div class="contact-header">
					<center><span style=""><h3></h3></span></center><br><br>
				</div>
			
			
			
            <h4 align="center"> Your Update was successful!</h4>
			<br><br>
			<center> <?php echo '<a class="btn btn-info" href="view_candidates.php">Back</a>'; ?>  </center>

				<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

				</div>
		</div>
	</div>
		
<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>