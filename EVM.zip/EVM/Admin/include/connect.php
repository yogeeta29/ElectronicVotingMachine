<?php

$con = mysqli_connect("localhost","root","","evm") or die("Could not connect database");
//mysql_select_db($mysql_database, $con) or die("Could not select database");
?>