<head>
	    <link href="css/styleName.css" rel="stylesheet">
</head>
<?php
$login=$login_session;
$user="select * from admin where username='$login'";
$userDetails=mysqli_query($connection,$user);
$row = mysqli_fetch_assoc($userDetails);
$Name=$row['Name'];

echo "<h4>Welcome $Name</h4>" ;
?>