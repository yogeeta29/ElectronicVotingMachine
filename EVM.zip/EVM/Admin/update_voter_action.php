<?php
	
	include"session.php";
	$ElectionId = $_GET['id'];
	$add =$_GET['address'];
	
	
		if(isset($_POST["register"]))  
		{
			/*$election_id=$_POST['ElectionId']; */
			$name =$_POST['Name']; 
			$address =$_POST['address']; 
			$mobile =$_POST['mobile']; 
			$email_id =$_POST['email_id']; 
			$ward_no =$_POST['ward_no']; 

			if($address =='')
			{
				$address= $add;
			}
				

				$sql = "UPDATE `voter` SET  `Name`='$name',`address`='$address',`mobile`='$mobile',`email_id`='$email_id',`ward_no`='$ward_no' WHERE `ElectionId`='$ElectionId' ";

				mysqli_query($connection,$sql);

			// ----------------------------------------------------------------------
				
		}
			
?>
<!DOCTYPE html>
<html>
<head>
<title>Voter Update</title>   
<?php include("include/html_include.php"); 
		?>

<?php scripts();?>
 <link href="css/business-casual.min.css" rel="stylesheet">	
</head>

<body style="background-color:rgb(45, 29, 26);">
<?php //register_header(); ?>
	<div class="h_btm_bg" style="color:white;">	
		<?php //admin_sidebar(); ?>
		<div class="about-section" id="contact" style="">
			<div class="container">
				<div class="contact-header">
					<center><span style=""><h3></h3></span></center><br><br>
				</div>
			
			
			
            <h4 align="center"> Your Update was successful!</h4>
			<br><br>
			<center> <?php echo '<a class="btn btn-info" href="viewVoters.php">Go Back</a>'; ?>  </center>

				<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

				</div>
		</div>
	</div>
		
<!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>